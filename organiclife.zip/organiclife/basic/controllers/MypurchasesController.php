<?php

namespace app\controllers;

use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use Yii;

class MypurchasesController extends Controller
{
    public function beforeAction($id) {
        if (Yii::$app->user->isGuest) {
            return $this->redirect(['site/login']);
            return false;
        }

        if (parent::beforeAction($id)) {
            return true;
        }

        return false;
    }

    public function actionIndex()
    {
        return $this->render('index');
    }
}