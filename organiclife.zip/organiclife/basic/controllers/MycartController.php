<?php

namespace app\controllers;

use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use Yii;

class MycartController extends Controller
{
    public function beforeAction($id) {
        if (Yii::$app->user->isGuest) {
            return $this->redirect(['site/login']);
            return false;
        }

        if (parent::beforeAction($id)) {
            return true;
        }

        return false;
    }

    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionBuy() {
        return $this->render('buy');
    }

    public function actionBuyall() {
        return $this->render('buyall');
    }

    public function actionDel() {
        return $this->render('del');
    }

    public function actionDelall() {
        return $this->render('delall');
    }
}