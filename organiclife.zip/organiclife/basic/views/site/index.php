<div class="catalog-title"><h4>Каталог товаров</h4></div>
<?php
use yii\helpers\Html;

if (Yii::$app->user->isGuest) {
    $dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
    $sth = $dbh->prepare("SET NAMES UTF8");
    $sth->execute();
    $sth = $dbh->prepare("SELECT *, product.id as product_id FROM `product`");
    $sth->execute();
    $products = $sth->fetchAll();
    
    $user = Yii::$app->user->identity->id;
    foreach($products as $product) {
        echo '<div class="div-product-card">
        
            <div class="div-product-card-cover">'.Html::a('<img class="img-product-cover" src="../../../uploads/'.$product['cover'].'" alt="'.$product['cover'].'">', ['/site/fullcart?id='.$product['product_id']]).'</div>
            <div class="div-product-card-name">'.Html::a($product['name'], ['/site/fullcart?id='.$product['product_id']], ['class' => 'product-card-name']).'</div>
            <div class="div-product-card-price"><p class="product-card-price">$'.$product['price'].'</p></div>
            <div class="div-product-card-grade"><p class="product-card-grade">Рейтинг: '.$product['grade'].'</p></div>
            <div class="div-img-add"><div class="div-product-card-add"><img src="../../../uploads/cart.png" alt="cart.png" class="img-card-add">'.Html::a('В корзину', ['/site/login'], ['class' => 'product-card-add']).'</div></div>
            </div>';
    }
} else {
    $dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
    $sth = $dbh->prepare("SET NAMES UTF8");
    $sth->execute();
    $sth = $dbh->prepare("SELECT *, product.id as product_id FROM `product`");
    $sth->execute();
    $products = $sth->fetchAll();
    
    $user = Yii::$app->user->identity->id;
    foreach($products as $product) {
        echo '<div class="div-product-card">
        
        <div class="div-product-card-cover">'.Html::a('<img class="img-product-cover" src="../../../uploads/'.$product['cover'].'" alt="'.$product['cover'].'">', ['/site/fullcart?id='.$product['product_id']]).'</div>
        <div class="div-product-card-name">'.Html::a($product['name'], ['/site/fullcart?id='.$product['product_id']], ['class' => 'product-card-name']).'</div>
            <div class="div-product-card-price"><p class="product-card-price">$'.$product['price'].'</p></div>
            <div class="div-product-card-grade"><p class="product-card-grade">Рейтинг: '.$product['grade'].'</p></div>
            <div class="div-img-add"><div class="div-product-card-add"><img src="../../../uploads/cart.png" alt="cart.png" class="img-card-add">'.Html::a('В корзину', ['site/add?user='.urlencode($user).'&product='.urlencode($product['id'])], ['class' => 'product-card-add']).'</div></div>
            </div>';
    }
}
?>