<?php
$dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$product = $_GET['product'];
$user = $_GET['user'];
$grade = $_GET['grade'];
$comment = $_GET['comment'];
$sth = $dbh->prepare("INSERT INTO `review` (`idUser`, `idProduct`, `grade`, `comment`) values ('".$user."', '".$product."', '".$grade."', '".$comment."')");
$sth->execute([
    ':idUser' => $user,
    ':idProduct' => $product,
    ':grade' => $grade,
    ':comment' => $comment
]);
?>
<script>
    location.replace('index');
</script>