<?php
$dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$user = $_GET['user'];
$product = $_GET['product'];
$sth = $dbh->prepare("INSERT INTO `cart` (`idUser`, `idProduct`) values ('".$user."', '".$product."')");
$sth->execute([
    ':idUser' => $user,
    ':idProduct' => $product,
]);
?>
<script>
    location.replace('index');
</script>