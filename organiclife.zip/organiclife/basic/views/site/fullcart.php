<div class="catalog-title"><h4>Каталог товаров</h4></div>
<?php
use yii\helpers\Html;
use yii\helpers\Url;

if (Yii::$app->user->isGuest) {
$dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$id = $_GET['id'];
$sth = $dbh->prepare("SELECT *, product.id as product_id FROM `product` WHERE id = '".$id."'");
$sth->execute();
$products = $sth->fetchAll();

foreach($products as $product) {
    echo '<div class="div-full-product">';
    echo '<div class="div-full-product-img">
            <img src="../../../uploads/'.$product['cover'].'" alt="'.$product['cover'].'" class="full-product-img">
        </div>';
    echo '<div class="div-full-product-other">
                <p class="full-product-name">'.$product['name'].'</p>
                <p class="full-product-price">$'.$product['price'].' each</p>
                <p class="full-product-description">'.$product['description'].'</p><br>
                '.Html::a('В корзину', ['/site/login'], ['class' => 'full-product-card-add']).'
        </div>';
    echo '</div>';
    echo '<div class="line-reviews-first"></div>
    <div class="form-send-review">
    <form action="'.Url::toRoute(["/site/login"]).'" method="get">
        <p class="p-name-review-product">Ваш комментарий: </p><input type="text" name="comment" class="name-review-product">
        <p class="p-grade-review-product">Ваша оценка: </p><input type="number" name="grade" class="grade-review-product" min="1" max="5">
        <input type="text" name="product" value="'.$product['id'].'" hidden />
        <p></p><input type="submit" value="Отправить комментарий" class="submit-review-product-button">
    </form>
    </div>
    <div class="line-reviews-second"></div>
    <br>
    <p class="title-list-reviews">Product Reviews:</p>';
}
$sth = $dbh->prepare("SELECT * FROM `review` JOIN `user` ON review.idUser = user.id WHERE review.idProduct = '".$product['id']."' ORDER BY `timestamp` DESC");
$sth->execute();
$reviews = $sth->fetchAll();

foreach($reviews as $review) {
    echo '<div class="form-view-comment">
        <p class="review-username">'.$review['username'].'</p>
        <p class="review-grade">'.$review['grade'].'</p>
        <p class="review-timestamp">'.$review['timestamp'].'</p>
        <p class="review-comment">'.$review['comment'].'</p>
        </div>';
}
} else {
$dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$id = $_GET['id'];
$sth = $dbh->prepare("SELECT *, product.id as product_id FROM `product` WHERE id = '".$id."'");
$sth->execute();
$products = $sth->fetchAll();

$user = Yii::$app->user->identity->id;
foreach($products as $product) {
    echo '<div class="div-full-product">';
    echo '<div class="div-full-product-img">
            <img src="../../../uploads/'.$product['cover'].'" alt="'.$product['cover'].'" class="full-product-img">
        </div>';
    echo '<div class="div-full-product-other">
                <p class="full-product-name">'.$product['name'].'</p>
                <p class="full-product-price">$'.$product['price'].' each</p>
                <p class="full-product-description">'.$product['description'].'</p><br>
                '.Html::a('В корзину', ['site/add?user='.urlencode($user).'&product='.urlencode($product['id'])], ['class' => 'full-product-card-add']).'
        </div>';
    echo '</div>';
    echo '<div class="line-reviews-first"></div>
    <div class="form-send-review">
    <form action="'.Url::toRoute(["/site/addreview"]).'" method="get">
        <p class="p-name-review-product">Ваш комментарий: </p><input type="text" name="comment" class="name-review-product">
        <p class="p-grade-review-product">Ваша оценка: </p><input type="number" name="grade" class="grade-review-product" min="1" max="5">
        <input type="text" name="user" value="'.$user.'"  hidden />
        <input type="text" name="product" value="'.$product['id'].'" hidden />
        <p></p><input type="submit" value="Отправить комментарий" class="submit-review-product-button">
    </form>
    </div>
    <div class="line-reviews-second"></div>
    <br>
    <p class="title-list-reviews">Product Reviews:</p>';
}
$sth = $dbh->prepare("SELECT * FROM `review` JOIN `user` ON review.idUser = user.id WHERE review.idProduct = '".$product['id']."' ORDER BY `timestamp` DESC");
$sth->execute();
$reviews = $sth->fetchAll();

foreach($reviews as $review) {
    echo '<div class="form-view-comment">
        <p class="review-username">'.$review['username'].'</p>
        <p class="review-grade">'.$review['grade'].'</p>
        <p class="review-timestamp">'.$review['timestamp'].'</p>
        <p class="review-comment">'.$review['comment'].'</p>
        </div>';
}
}
?>