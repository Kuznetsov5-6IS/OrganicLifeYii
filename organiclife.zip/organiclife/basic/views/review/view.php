<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Review */

$this->title = $model->comment;
$this->params['breadcrumbs'][] = ['label' => 'Все отзывы', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="review-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Редактировать', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Удалить', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Вы уверены что хотите удалить отзыв с комментарием '.$model->comment.' ?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            // 'idUser',
            [
                'label' => 'Пользователь',
                'value' => function($data) { return $data->user->username; }
            ],
            // 'idProduct',
            [
                'label' => 'Товар',
                'value' => function($data) { return $data->product->name; }
            ],
            'grade',
            'comment:ntext',
            'timestamp',
        ],
    ]) ?>

</div>
