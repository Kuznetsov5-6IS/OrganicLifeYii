<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Cart */

$this->title = $model->product->name;
$this->params['breadcrumbs'][] = ['label' => 'Вся корзина', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="cart-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Редактировать', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Удалить', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Вы точно хотите удалить товар из корзины с названием '.$model->product->name.' ?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            // 'idUser',
            [
                'label' => 'Пользователь',
                'value' => function($data) { return $data->user->username; }
            ],
            // 'idProduct',
            [
                'label' => 'Товар',
                'value' => function($data) { return $data->product->name; }
            ],
        ],
    ]) ?>

</div>
