<?php
$dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$user = $_GET['user'];
$product = $_GET['product'];
$price = $_GET['price'];
$balance = $_GET['balance'];
$sth = $dbh->prepare("START TRANSACTION; INSERT INTO `buy` (`idUser`, `idProduct`, `price`) values ('".$user."', '".$product."', '".$price."'); UPDATE `user` SET balance = '".$balance."' where id = '".$user."'; delete from `cart` where idUser = '".$user."'; COMMIT;");
$sth->execute([
    ':idUser' => $user,
    ':idProduct' => $product,
    ':price' => $price,
    ':balance' => $balance,
]);
?>
<script>
    location.replace('index');
</script>