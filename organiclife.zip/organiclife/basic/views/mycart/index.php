<?php
use yii\helpers\Html;

$user = Yii::$app->user->identity->id;

$dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$sth = $dbh->prepare("SELECT *, cart.idUser as user_id, cart.id as cart_id, cart.idProduct as cart_product FROM `cart` JOIN `product` ON cart.idProduct = product.id WHERE cart.idUser = '".$user."'");
$sth->execute();
$carts = $sth->fetchAll();

$sth = $dbh->prepare("SELECT sum(price) as total, count(price) as quentity FROM `product` JOIN `cart` ON product.id = cart.idProduct WHERE idUser = '".$user."'");
$sth->execute();
$prices = $sth->fetchAll();
foreach($prices as $price) {
    
}

$sth = $dbh->prepare("SELECT * FROM `user` WHERE id = '".$user."'");
$sth->execute();
$balances = $sth->fetchAll();
foreach($balances as $balance) {

}
echo '<p style="border: 1px solid #000; width: 100%; text-align: center; padding: 20px;">'.$balance['username'].', ВАШ ТЕКУЩИЙ БАЛАНС: $'.$balance['balance'].'</p>';
echo '<table class="my-cart-product-table">';
echo '<tr class="title-tr"><td>Изображение</td><td>Название</td><td>Рейтинг</td><td>Цена</td><td></td></tr>';
foreach($carts as $cart) {
        $newbalance = $balance['balance'] - $cart['price'];
        echo '<tr>
                <td><img src="../../../uploads/'.$cart['cover'].'" alt="'.$cart['cover'].'" class="my-cart-img-product"></td>
                <td>'.$cart['name'].'</td>
                <td>'.$cart['grade'].'</td>
                <td>$'.$cart['price'].'</td>
                <td>'.Html::a('Купить', ['mycart/buy?user='.urlencode($user).'&product='.urlencode($cart['cart_product']).'&price='.urlencode($cart['price']).'&balance='.urlencode($newbalance)], ['class' => 'my-cart-buy-button']).'</td>
                <td>'.Html::a('Очистить', ['mycart/del?id='.$cart['cart_id']], [
                        'class' => 'button-delete-my-cart']).'</td>
            </tr>';

}
$allbalance = $balance['balance'] - $price['total'];
echo '<tr><td>Кол-во: '.$price['quentity'].'</td><td>Цена: $'.$price['total'].'</td><td></td><td></td><td>'.Html::a('Купить все', ['mycart/buyall?user='.urlencode($user).'&product='.urlencode($price['quentity']).'&price='.urlencode($price['total']).'&balance='.urlencode($allbalance)], ['class' => 'my-cart-buy-all-button']).'</td><td>'.Html::a('Очистить все', ['mycart/delall?id='.$cart['user_id']], ['class' => 'button-all-delete-my-cart']).'</td>';
echo '</table';
