<?php
$dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$id = $_GET['id'];
$sth = $dbh->prepare("delete from `cart` where id = '".$id."'");
$sth->execute([
    ':id' => $id,
]);
?>
<script>
    location.replace('index');
</script>