<?php

/** @var yii\web\View $this */
/** @var string $content */

use yii\helpers\Url;
use app\assets\AppAsset;
use app\widgets\Alert;
use yii\bootstrap4\Breadcrumbs;
use yii\bootstrap4\Html;
use yii\bootstrap4\Nav;
use yii\bootstrap4\NavBar;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body class="d-flex flex-column h-100">
<?php $this->beginBody() ?>

<header>
    <?php
    NavBar::begin([
        'brandLabel' => Html::img('@web/logo/logo.png', ['class' => 'logo']),
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar navbar-expand-md',
        ],
    ]);
    $items = [];
    if (Yii::$app->user->isGuest) {
        $items[] = ['label' => 'Главная', 'url' => ['/site/index']];
        $items[] = ['label' => 'О нас', 'url' => ['/site/about']];
        $items[] = ['label' => 'Контакты', 'url' => ['/site/contact']];
        $items[] = ['label' => 'Регистрация', 'url' => ['/user/create']];
        $items[] = ['label' => 'Авторизация', 'url' => ['/site/login']];
        $items[] = '<div class="div-cart-button"><button class="cart-button" id="cart-button-guest"></button></div>';

        $dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
                        $sth = $dbh->prepare("SET NAMES UTF8");
                        $sth->execute();
                        $sth = $dbh->prepare("SELECT *, cart.id as cart_id FROM `cart` JOIN `product` ON cart.idProduct = product.id WHERE idUser = '".$user."' limit 2");
                        $sth->execute();
                        $carts = $sth->fetchAll();

                        $sth = $dbh->prepare("SELECT sum(price) as total, count(price) as quentity FROM `product` JOIN `cart` ON product.id = cart.idProduct WHERE idUser = '".$user."'");
                        $sth->execute();
                        $prices = $sth->fetchAll();
                        foreach($prices as $price) {

                        }
                        
                        
                        echo '<div class="div-open-cart-guest hidden" id="open-cart-guest">
                        <table class="table-product-cart">
                        <tr class="title-tr">
                        <td>Изображение</td><td>Название</td><td>Цена</td>
                        </tr>';
                        foreach($carts as $cart) {
                            echo '<tr>
                            <td><img src="../../../uploads/'.$cart['cover'].'" alt="'.$cart['cover'].'" class="cart-cover"></td>
                            <td>'.$cart['name'].'</td>
                            <td>$'.$cart['price'].'</td>
                            <td>'.Html::a('', ['site/del?id='.$cart['cart_id']], [
                                'class' => 'button-delete-cart']).'</td>
                            </tr>';
                        }
                        
                        echo '<tr>
                                <td>Кол-во</td><td></td><td>'.$price['quentity'].'</td>
                        </tr>
                        <tr>
                                <td>Итоговая стоимость</td><td></td><td>$'.$price['total'].'</td>  
                        </tr>
                        
                                
                        ';
                        echo '</table><div class="div-button-checkout">'.Html::a('Перейти к оформлению заказа', ['/site/login'], ['class' => 'button-checkout']).'</div></div>';


                    $items[] = '<div class="div-search-button"><button class="search-button" id="search-button"></button></div>';
        $items[] = '<div class="div-search-input hidden" id="open-search-input">


        <form action="'.Url::toRoute(['/site/search', 'id' => $model->id]).'" method="get">
        <input type="text" name="name" class="search-input" placeholder="Я ищу...">
        <input type="submit" value="Найти" class="search-submit">
        </form>';

    } else if (Yii::$app->user->identity->admin == 0) {
        $items[] = ['label' => 'Главная', 'url' => ['/site/index']];
        $items[] = ['label' => 'Моя корзина', 'url' => ['/mycart/index']];
        $items[] = ['label' => 'Мои покупки', 'url' => ['/mypurchases/index']];
        $items[] = ['label' => 'О нас', 'url' => ['/site/about']];
        $items[] = ['label' => 'Контакты', 'url' => ['/site/contact']];
        $items[] = '<div class="div-exit-button">'.Html::beginForm(['/site/logout'], 'post')
                . Html::submitButton(
                    'Выход (' . Yii::$app->user->identity->username . ')',
                    ['class' => 'exit-button']
                )
                . Html::endForm().
                '</div>';
                $user = Yii::$app->user->identity->id;
                
                $items[] = '<div class="div-cart-button"><button class="cart-button" id="cart-button-auth"></button></div>';

                        $dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
                        $sth = $dbh->prepare("SET NAMES UTF8");
                        $sth->execute();
                        $sth = $dbh->prepare("SELECT *, cart.id as cart_id FROM `cart` JOIN `product` ON cart.idProduct = product.id WHERE idUser = '".$user."' limit 2");
                        $sth->execute();
                        $carts = $sth->fetchAll();

                        $sth = $dbh->prepare("SELECT sum(price) as total, count(price) as quentity FROM `product` JOIN `cart` ON product.id = cart.idProduct WHERE idUser = '".$user."'");
                        $sth->execute();
                        $prices = $sth->fetchAll();
                        foreach($prices as $price) {

                        }
                        
                        
                        echo '<div class="div-open-cart-auth hidden" id="open-cart-auth">
                        <table class="table-product-cart">
                        <tr class="title-tr">
                        <td>Изображение</td><td>Название</td><td>Цена</td>
                        </tr>';
                        foreach($carts as $cart) {
                            echo '<tr>
                            <td><img src="../../../uploads/'.$cart['cover'].'" alt="'.$cart['cover'].'" class="cart-cover"></td>
                            <td>'.$cart['name'].'</td>
                            <td>$'.$cart['price'].'</td>
                            <td>'.Html::a('', ['site/del?id='.$cart['cart_id']], ['class' => 'button-delete-cart']).'</td>
                            </tr>';
                        }
                        
                        echo '<tr>
                                <td>Кол-во</td><td></td><td>'.$price['quentity'].'</td>
                        </tr>
                        <tr>
                                <td>Итоговая стоимость</td><td></td><td>$'.$price['total'].'</td>  
                        </tr>
                        
                                
                        ';
                        echo '</table><div class="div-button-checkout">'.Html::a('Перейти к оформлению заказа', ['/mycart/index'], ['class' => 'button-checkout']).'</div></div>';
        $items[] = '<div class="div-search-button"><button class="search-button" id="search-button"></button></div>';
        $items[] = '<div class="div-search-input hidden" id="open-search-input">


        <form action="'.Url::toRoute(['/site/search', 'id' => $model->id]).'" method="get">
        <input type="text" name="name" class="search-input" placeholder="Я ищу...">
        <input type="submit" value="Найти" class="search-submit">
        </form>';

    } else if (Yii::$app->user->identity->admin == 1) {
        $items[] = ['label' => 'Главная', 'url' => ['/site/index']];
        $items[] = ['label' => 'Административная панель', 'url' => ['/admin/index']];
        $items[] = ['label' => 'Моя корзина', 'url' => ['/mycart/index']];
        $items[] = ['label' => 'Мои покупки', 'url' => ['/mypurchases/index']];
        $items[] = ['label' => 'О нас', 'url' => ['/site/about']];
        $items[] = ['label' => 'Контакты', 'url' => ['/site/contact']];
        $items[] = '<div class="div-exit-button">'.Html::beginForm(['/site/logout'], 'post')
                . Html::submitButton(
                    'Выход (' . Yii::$app->user->identity->username . ')',
                    ['class' => 'exit-button']
                )
                . Html::endForm().
                '</div>';
                $user = Yii::$app->user->identity->id;
                
                $items[] = '<div class="div-cart-button"><button class="cart-button" id="cart-button-auth"></button></div>';

                        $dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
                        $sth = $dbh->prepare("SET NAMES UTF8");
                        $sth->execute();
                        $sth = $dbh->prepare("SELECT *, cart.id as cart_id FROM `cart` JOIN `product` ON cart.idProduct = product.id WHERE idUser = '".$user."' limit 2");
                        $sth->execute();
                        $carts = $sth->fetchAll();

                        $sth = $dbh->prepare("SELECT sum(price) as total, count(price) as quentity FROM `product` JOIN `cart` ON product.id = cart.idProduct WHERE idUser = '".$user."'");
                        $sth->execute();
                        $prices = $sth->fetchAll();
                        foreach($prices as $price) {

                        }
                        
                        
                        echo '<div class="div-open-cart-auth hidden" id="open-cart-auth">
                        <table class="table-product-cart">
                        <tr class="title-tr">
                        <td>Изображение</td><td>Название</td><td>Цена</td>
                        </tr>';
                        foreach($carts as $cart) {
                            echo '<tr>
                            <td><img src="../../../uploads/'.$cart['cover'].'" alt="'.$cart['cover'].'" class="cart-cover"></td>
                            <td>'.$cart['name'].'</td>
                            <td>$'.$cart['price'].'</td>
                            <td>'.Html::a('', ['site/del?id='.$cart['cart_id']], [
                                'class' => 'button-delete-cart']).'</td>
                            </tr>';
                        }
                        
                        echo '<tr>
                                <td>Кол-во</td><td></td><td>'.$price['quentity'].'</td>
                        </tr>
                        <tr>
                                <td>Итоговая стоимость</td><td></td><td>$'.$price['total'].'</td>  
                        </tr>
                        
                                
                        ';
                        echo '</table><div class="div-button-checkout">'.Html::a('Перейти к оформлению заказа', ['/mycart/index'], ['class' => 'button-checkout']).'</div></div>';
        $items[] = '<div class="div-search-button"><button class="search-button" id="search-button"></button></div>';
        $items[] = '<div class="div-search-input hidden" id="open-search-input">


        <form action="'.Url::toRoute(['/site/search', 'id' => $model->id]).'" method="get">
        <input type="text" name="name" class="search-input" placeholder="Я ищу...">
        <input type="submit" value="Найти" class="search-submit">
        </form>';
    }
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav'],
        'items' => $items,
    ]);
    NavBar::end();
    ?>
</header>

<main role="main" class="flex-shrink-0">
    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
</main>

<footer class="footer mt-auto py-3 text-muted">
    <div class="container">
        <p class="float-left">COPYRIGHT © 2022 SHAPER ORGANIC LIFE. ALL RIGHTS RESERVED.</p>
        <p class="float-right"><?php echo date('d.m.y'); ?></p>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
<script>
document.getElementById('cart-button').onclick = function() {
    document.getElementById('open-cart').classList.toggle('hidden');
}
</script>
<script>
document.getElementById('cart-button-auth').onclick = function() {
    document.getElementById('open-cart-auth').classList.toggle('hidden');
}
</script>
<script>
document.getElementById('cart-button-guest').onclick = function() {
    document.getElementById('open-cart-guest').classList.toggle('hidden');
}
</script>
<script>
document.getElementById('search-button').onclick = function() {
    document.getElementById('open-search-input').classList.toggle('hidden');
}
</script>