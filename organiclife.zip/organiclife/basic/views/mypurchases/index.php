<?php
use yii\helpers\Html;

$user = Yii::$app->user->identity->id;

$dbh = new PDO('mysql:dbname=fruitshop;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$sth = $dbh->prepare("SELECT * FROM `buy` JOIN `product` ON buy.idProduct = product.id WHERE buy.idUser = '".$user."' ORDER BY timestamp DESC");
$sth->execute();
$carts = $sth->fetchAll();

$sth = $dbh->prepare("SELECT sum(price) as total, count(price) as quentity FROM `buy` WHERE buy.idUser = '".$user."'");
$sth->execute();
$prices = $sth->fetchAll();
foreach($prices as $price) {
    
}

echo '<table class="my-cart-product-table">';
echo '<tr class="title-tr"><td>Изображение</td><td>Название</td><td>Рейтинг</td><td>Цена</td><td>Время покупки</td></tr>';
foreach($carts as $cart) {
        echo '<tr>
                <td><img src="../../../uploads/'.$cart['cover'].'" alt="'.$cart['cover'].'" class="my-cart-img-product"></td>
                <td>'.$cart['name'].'</td>
                <td>'.$cart['grade'].'</td>
                <td>$'.$cart['price'].'</td>
                <td>'.$cart['timestamp'].'</td>
            </tr>';

}
echo '<tr><td>Кол-во: '.$price['quentity'].'</td><td>Цена: $'.$price['total'].'</td></tr>';
echo '</table';