<?php

namespace app\models;

use Yii;

class RegForm extends User
{
    public function rules()
    {
        return [
            [['name', 'username', 'email', 'password', 'confirmPassword', 'agree'], 'required', 'message' => 'Поле обязательно для заполнения'],
            [['idKit', 'admin'], 'integer'],
            [['name', 'username', 'email', 'password'], 'string', 'max' => 255],
            [['idKit'], 'exist', 'skipOnError' => true, 'targetClass' => Kit::className(), 'targetAttribute' => ['idKit' => 'id']],
            ['name', 'match', 'pattern' => '/^[А-Яа-я\s\-]{5,}$/u', 'message' => 'Только кириллица, дефисы и пробелы'],
            ['username', 'match', 'pattern' => '/^[A-Za-z]{5,}$/u', 'message' => 'Только латиница'],
            ['email', 'email', 'message' => 'Некорректный email'],
            ['confirmPassword', 'compare', 'compareAttribute' => 'password', 'message' => 'Пароли не совпадают'],
            ['agree', 'boolean'],
            ['agree', 'compare', 'compareValue' => true, 'message' => 'Необходимо согласиться'],
        ];
    }
}