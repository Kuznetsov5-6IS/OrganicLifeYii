<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "product".
 *
 * @property int $id
 * @property string $cover
 * @property string $name
 * @property float $grade
 * @property float $price
 * @property string $description
 *
 * @property Review[] $reviews
 */
class Product extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'product';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cover', 'name', 'grade', 'price', 'description'], 'required'],
            [['grade', 'price'], 'number'],
            [['description'], 'string'],
            [['cover', 'name'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'cover' => 'Изображение',
            'name' => 'Название',
            'grade' => 'Рейтинг',
            'price' => 'Цена',
            'description' => 'Описание',
        ];
    }

    /**
     * Gets query for [[Reviews]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getReviews()
    {
        return $this->hasMany(Review::className(), ['idProduct' => 'id']);
    }
}
