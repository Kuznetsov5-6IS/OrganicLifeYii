<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "review".
 *
 * @property int $id
 * @property int $idUser
 * @property int $idProduct
 * @property float $grade
 * @property string $timestamp
 * @property string $comment
 *
 * @property Product $idProduct0
 * @property User $idUser0
 */
class Review extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'review';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['idUser', 'idProduct', 'grade', 'comment'], 'required'],
            [['idUser', 'idProduct'], 'integer'],
            [['grade'], 'number'],
            [['timestamp'], 'safe'],
            [['comment'], 'string'],
            [['idProduct'], 'exist', 'skipOnError' => true, 'targetClass' => Product::className(), 'targetAttribute' => ['idProduct' => 'id']],
            [['idUser'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['idUser' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'idUser' => 'Пользователь',
            'idProduct' => 'Товар',
            'grade' => 'Рейтинг',
            'timestamp' => 'Временная метка',
            'comment' => 'Комментарий',
        ];
    }

    /**
     * Gets query for [[IdProduct0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['id' => 'idProduct']);
    }

    /**
     * Gets query for [[IdUser0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'idUser']);
    }
}
