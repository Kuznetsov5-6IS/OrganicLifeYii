-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 18 2022 г., 17:26
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `fruitshop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `buy`
--

CREATE TABLE `buy` (
  `id` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idProduct` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `buy`
--

INSERT INTO `buy` (`id`, `idUser`, `idProduct`, `price`, `timestamp`) VALUES
(66, 1, 2, '19.00', '2022-06-24 19:43:09'),
(67, 6, 1, '79.00', '2022-06-24 19:49:22'),
(68, 6, 4, '15.00', '2022-06-24 19:49:43'),
(69, 6, 2, '149.00', '2022-06-24 19:49:56'),
(70, 6, 8, '70.00', '2022-06-24 19:50:46'),
(71, 1, 1, '79.00', '2022-06-24 20:35:23'),
(72, 1, 2, '19.00', '2022-06-24 20:35:43'),
(73, 1, 5, '184.00', '2022-06-24 20:37:09'),
(74, 1, 1, '79.00', '2022-06-26 10:17:39'),
(75, 1, 7, '69.00', '2022-06-26 10:25:56'),
(76, 1, 8, '70.00', '2022-06-26 10:25:58'),
(77, 1, 8, '70.00', '2022-06-26 18:56:35'),
(78, 1, 7, '69.00', '2022-06-26 18:56:46'),
(79, 1, 6, '80.00', '2022-06-26 18:57:47'),
(80, 2, 2, '19.00', '2022-06-26 18:58:00'),
(81, 2, 3, '39.00', '2022-06-26 18:58:02'),
(85, 1, 3, '39.00', '2022-06-27 15:39:33'),
(86, 1, 1, '79.00', '2022-06-27 15:40:48'),
(87, 2, 4, '15.00', '2022-06-27 15:41:51'),
(88, 2, 7, '69.00', '2022-06-27 15:41:55'),
(89, 2, 4, '15.00', '2022-06-27 15:43:34'),
(90, 1, 8, '70.00', '2022-06-30 14:11:35');

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idProduct` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `idUser`, `idProduct`) VALUES
(197, 2, 3),
(199, 1, 7),
(200, 1, 6),
(201, 1, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `kit`
--

CREATE TABLE `kit` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `kit`
--

INSERT INTO `kit` (`id`, `name`, `price`, `description`) VALUES
(1, 'None', '0.00', 'None'),
(2, 'Starter', '19.00', '5 Domain Names\r\n1GB Dedicated Ram\r\n5 Sub Domain\r\n10 Addon Domain\r\n24/7 Support\r\n5 Domain Names'),
(3, 'Business', '129.00', '5 Domain Names\r\n1GB Dedicated Ram\r\n5 Sub Domain\r\n10 Addon Domain\r\n24/7 Support\r\n5 Domain Names'),
(4, 'Basic', '49.00', '5 Domain Names\r\n1GB Dedicated Ram\r\n5 Sub Domain\r\n10 Addon Domain\r\n24/7 Support\r\n5 Domain Names'),
(5, 'Ultra', '199.00', '5 Domain Names\r\n1GB Dedicated Ram\r\n5 Sub Domain\r\n10 Addon Domain\r\n24/7 Support\r\n5 Domain Names');

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `grade` decimal(10,1) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id`, `cover`, `name`, `grade`, `price`, `description`) VALUES
(1, 'australianapple.jpg', 'Яблоко', '4.0', '79.00', 'Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ips ...'),
(2, 'cabbage.jpg', 'Капуста', '5.0', '19.00', 'Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ips ...'),
(3, 'nuts.jpg', 'Орехи', '4.2', '39.00', 'Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ips ...'),
(4, 'sweetcarrot.jpg', 'Морковь', '3.4', '15.00', 'Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ips ...'),
(5, 'chinagepotato.jpg', ' Картофель', '2.5', '10.00', 'Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ips ...'),
(6, 'bromelainpineapple.png', 'Ананас', '4.6', '80.00', 'Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ips ...'),
(7, 'alicemango.jpg', 'Манго', '4.1', '69.00', 'Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ips ...'),
(8, 'belizepapaw.jpg', 'Папайя', '3.2', '70.00', 'Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ipsum dolor sit amet tail salami t-bone, tongue capicola drumstick swine. Landjaeger filet mignon boudin drumstick, biltong rump leberkas jowl tenderloin ham salami short loin. Bacon ips ...');

-- --------------------------------------------------------

--
-- Структура таблицы `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idProduct` int(11) NOT NULL,
  `grade` decimal(10,1) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `review`
--

INSERT INTO `review` (`id`, `idUser`, `idProduct`, `grade`, `timestamp`, `comment`) VALUES
(1, 1, 1, '4.9', '2022-06-22 06:27:46', 'It\'s so perfect!'),
(2, 1, 1, '2.0', '2022-06-26 09:26:23', 'Bad..'),
(3, 2, 7, '4.0', '2022-06-26 09:49:28', 'Not bad!'),
(4, 1, 1, '4.0', '2022-06-26 09:58:23', 'Delicious!'),
(5, 1, 8, '5.0', '2022-06-26 10:18:10', 'Wow!!!'),
(6, 1, 7, '5.0', '2022-06-26 10:25:46', 'Cool!'),
(7, 1, 6, '5.0', '2022-06-26 18:57:17', 'Excellent!'),
(8, 1, 4, '5.0', '2022-06-27 15:40:26', 'More carrots! More!');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT 1000.00,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `idKit` int(11) NOT NULL DEFAULT 1,
  `admin` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `balance`, `email`, `password`, `idKit`, `admin`) VALUES
(1, 'timur', 'timur', '93.00', 'timur@timur.timur', 'timur', 1, 0),
(2, 'admin', 'admin', '99169.00', 'admin@admin.admin', 'admin', 5, 1),
(6, 'Вася Пупкин', 'pupkin', '687.00', 'pupkin@pupkin.pupkin', 'pupkin', 1, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `buy`
--
ALTER TABLE `buy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUser` (`idUser`),
  ADD KEY `idProduct` (`idProduct`);

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUser` (`idUser`),
  ADD KEY `idProduct` (`idProduct`);

--
-- Индексы таблицы `kit`
--
ALTER TABLE `kit`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUser` (`idUser`),
  ADD KEY `idProduct` (`idProduct`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idKit` (`idKit`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `buy`
--
ALTER TABLE `buy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT для таблицы `kit`
--
ALTER TABLE `kit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `buy`
--
ALTER TABLE `buy`
  ADD CONSTRAINT `buy_ibfk_2` FOREIGN KEY (`idUser`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `buy_ibfk_3` FOREIGN KEY (`idProduct`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`idProduct`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`idProduct`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`idUser`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`idKit`) REFERENCES `kit` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
